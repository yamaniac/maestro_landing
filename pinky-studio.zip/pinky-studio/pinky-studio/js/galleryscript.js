$(function(){
    $('#img-row').mixItUp();
});

  /* activate jquery isotope */
$.getScript('//cdn.jsdelivr.net/isotope/1.5.25/jquery.isotope.min.js',function(){

  $('#img-row').imagesLoaded( function(){
    $('#img-row').isotope({
      itemSelector : '.item'
    });
  });