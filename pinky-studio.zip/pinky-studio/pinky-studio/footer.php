<!--footer-->
<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-3">All Rights Reserved � 2015.</div>
          <div class="col-md-6 foot_links"><a href="#">About Us</a>    |    <a href="#">Disclaimer </a>   |    <a href="#">Privacy Policy</a>    |    <a href="#">Contact Us</a></div>
            <div class="col-md-3 creds">  Powered by :
            <a target="_blank" title="Pacesoft Technologies" href="http://www.pacesoft.net">
            <img src="img/pacesoft.png" width="34" height="35"> </a>
            </div>
        </div>   
    </div>
</footer>
<!--footer-->

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
        <script src="js/plugins.js"></script>
        <script src="js/jquery.prettyPhoto.js"></script>
        <script src="js/main.js"></script>
    
    <script src="js/bootstrap.min.js"></script>
    <script src="js/holder.min.js"></script>
    <script src="js/jquery.mixitup.min.js"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src="js/ie10-viewport-bug-workaround.js"></script>
    
    <script>
    $(function(){
    $('#Container').mixItUp();
});



            $(document).ready(function(){
                $("[rel^='lightbox']").prettyPhoto();
            });
    
    </script>
    
  </body>
</html>
