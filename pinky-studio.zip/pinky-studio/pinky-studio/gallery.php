<?php include "header.php"; ?>
<?php include "menu.php"; ?>

<div class="galleryheader">
 <div class="container">
  <div class="row">
  <div class="col-md-12 text-center gallery_heading_top-buffer">
  <h2>Photo Gallery</h2>
<p>About the photo gallery</p>
  </div>
 </div>


</div>
</div>
<div class="top-buffer"></div>
	<div id="project-version-two" class="col-lg-12 gallery-filter-wrapper">
		<ul class="gallery-filter masonary">
			<li class="filter" data-filter="all" class="active">
			<span>Wedding</span>
			</li>
			<li class="filter" data-filter=".category-1">
			<span>Couple Shots</span>
			</li>
			<li class="filter" data-filter=".category-4">
			<span>Tini Captures</span>
			</li>
			<li class="filter" data-filter=".category-2"">
			<span>Events and Celebrations</span>
			</li>
		</ul>
	</div>
<div id="Container">
            
<div id="img-row" class="row">
<div id="1" class="item col-md-3 mix category-1 hvr-bob" data-my-order="2">

<a class="thumbnail" rel="lightbox[group]" href="img/pics/1.jpg"><img class="group1 img-responsive" src="img/pics/1.jpg" title="Image Title" /></a>

</div>
<div id="2" class="item col-md-3 mix category-2 hvr-bob" data-my-order="2">

<a class="thumbnail" rel="lightbox[group]" href="img/pics/2.jpg"><img class="group1 img-responsive" src="img/pics/2.jpg" title="Image Title" /></a>

</div>
<div id="3" class="item col-md-3 mix category-1 hvr-bob" data-my-order="1">

<a class="thumbnail" rel="lightbox[group]" href="img/pics/3.jpg"><img class="group1 img-responsive" src="img/pics/3.jpg" title="Image Title" /></a>

</div>
<div id="4" class="item col-md-3 mix category-2 hvr-bob" data-my-order="2">

<a class="thumbnail" rel="lightbox[group]" href="img/pics/4.jpg"><img class="group1 img-responsive" src="img/pics/4.jpg" title="Image Title" /></a>

</div>
<div id="5" class="item col-md-3 mix category-3 hvr-bob" data-my-order="1">

 <a class="thumbnail" rel="lightbox[group]" href="img/pics/5.jpg"><img class="group1 img-responsive" src="img/pics/5.jpg" title="Image Title" /></a>

</div>
<div id="6" class="item col-md-3 mix category-2 hvr-bob" data-my-order="1">

<a class="thumbnail" rel="lightbox[group]" href="img/pics/6.jpg"><img class="group1 img-responsive" src="img/pics/6.jpg" title="Image Title" /></a>

</div>
<div id="7" class="item col-md-3 mix category-1 hvr-bob" data-my-order="1">
<div class="image-caption">Life <strong>Begins</strong>
<p>This is a description</p>

</div>
 <a class="thumbnail" rel="lightbox[group]" href="img/pics/7.jpg"><img class="group1 img-responsive" src="img/pics/7.jpg" title="Image Title" /></a>

</div>
<div id="8" class="item col-md-3 mix category-4 hvr-bob" data-my-order="2">

 <a class="thumbnail" rel="lightbox[group]" href="img/pics/8.jpg"><img class="group1 img-responsive" src="img/pics/8.jpg" title="Image Title" /></a>

</div>
<div id="9" class="item col-md-3 mix category-1 hvr-bob" data-my-order="1">

 <a class="thumbnail" rel="lightbox[group]" href="img/pics/8.jpg"><img class="group1 img-responsive" src="img/pics/8.jpg" title="Image Title" /></a>

</div>
<div id="10" class="item col-md-3 mix category-4 hvr-bob" data-my-order="2">

 <a class="thumbnail" rel="lightbox[group]" href="img/pics/8.jpg"><img class="group1 img-responsive" src="img/pics/8.jpg" title="Image Title" /></a>

</div>
<div id="11" class="item col-md-3 mix category-1 hvr-bob" data-my-order="2">

 <a class="thumbnail" rel="lightbox[group]" href="img/pics/8.jpg"><img class="group1 img-responsive" src="img/pics/8.jpg" title="Image Title" /></a>

</div>
<div id="12" class="item col-md-3 mix category-4 hvr-bob" data-my-order="1">

 <a class="thumbnail" rel="lightbox[group]" href="img/pics/8.jpg"><img class="group1 img-responsive" src="img/pics/8.jpg" title="Image Title" /></a>

</div>
<div id="13" class="item col-md-3 mix category-3 hvr-bob" data-my-order="2">

 <a class="thumbnail img-responsive" rel="lightbox[group]" href="img/pics/8.jpg"><img class="group1 img-responsive" src="img/pics/8.jpg" title="Image Title" /></a>

</div>
<div id="14" class="item col-md-3 mix category-4 hvr-bob" data-my-order="1">

 <a class="thumbnail img-responsive" rel="lightbox[group]" href="img/pics/8.jpg"><img class="group1 img-responsive" src="img/pics/8.jpg" title="Image Title" /></a>

</div>
<div id="15" class="item col-md-3 mix category-1 hvr-bob" data-my-order="1">

 <a class="thumbnail img-responsive" rel="lightbox[group]" href="img/pics/8.jpg"><img class="group1 img-responsive" src="img/pics/8.jpg" title="Image Title" /></a>

</div>
<div id="16" class="item col-md-3 mix category-4 hvr-bobhvr-bob" data-my-order="2">

 <a class="thumbnail" rel="lightbox[group]" href="img/pics/8.jpg"><img class="group1 img-responsive" src="img/pics/8.jpg" title="Image Title" /></a>

</div>

</div>
</div>
 

            





<?php include 'galleryscript.js';?>

<?php include 'footer.php'; ?>
