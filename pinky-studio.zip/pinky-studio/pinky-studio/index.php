<?php include "header.php"; ?>
<?php include "menu.php"; ?>


    <!-- Carousel
    ================================================== -->
    <div id="myCarousel" class="carousel slide" data-ride="carousel">
      <!-- Indicators -->
      <ol class="carousel-indicators">
        <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
        <li data-target="#myCarousel" data-slide-to="1"></li>
        <li data-target="#myCarousel" data-slide-to="2"></li>
      </ol>
      <div class="carousel-inner" role="listbox">
        <div class="item active">
   	    <img src="img/banner1.jpg" width="1500" height="500">
        </div>
        <div class="item">
         <img class="img-responsive" src="holder.js/1500x500">
          
        </div>
        <div class="item">
          <img class="img-responsive" src="holder.js/1500x500">
        </div>
      </div>
      <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
        <span class="glyphicon glyphicon-chevron-left" aria-hidden="true"></span>
        <span class="sr-only">Previous</span>
      </a>
      <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
        <span class="glyphicon glyphicon-chevron-right" aria-hidden="true"></span>
        <span class="sr-only">Next</span>
      </a>
    </div><!-- /.carousel -->

<!--about us section-->
    <div class="about_us">
        <div class="container">
            <div class="row">
                <h2>About</h2>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged</p>
                <a class=" bordered_btn">More</a>
            </div>
        </div>
    </div>
<!--about us section-->



<!--wedding section-->
<div class="container">
    <div class="row">
    <div class="col-md-12">
    <h2 class="wedding_heading">Wedding</h2>
    <div class="wedding">
        
        <ul class="wedding_section">
            <li>
                <a href="">
                <img class="img-responsive" src="img/wed1.jpg">
                <h3><strong>CANDID</strong>Wedding</h3>
                </a>
            </li>
            <li>
                <a href="">
                <img class="img-responsive" src="img/wed2.jpg">
                <h3><strong>TRADITIONAL</strong>Photography</h3>
                </a>
            </li>
            <li>
                <a href="">
                <img class="img-responsive" src="img/wed3.jpg">
                <h3><strong>CINEMATIC</strong>Wedding</h3>
                </a>
            </li>
            <li>
                <a href="">
                <img class="img-responsive" src="img/wed4.jpg">
                <h3><strong>TRADITIONAL</strong>Videography</h3>
                </a>
            </li>
            <li>
                <a href="">
                <img class="img-responsive" src="img/wed5.jpg">
                <h3><strong>DESTINATION</strong>Wedding</h3>
                </a>
            </li>
        </ul>
    </div>
    </div>
    
    
    </div>
    
    <div class="row">
    
        <div class="col-md-6">
            <div class="red_box">
                <div class="row">
                <div class="col-md-6 col-xs-6">
                    <img class="img-responsive" src="img/pre.jpg">
                </div>
                
                <div class="col-md-6 col-xs-6">
                    <h4><strong>PRE</strong><br />Wedding</h4>
                </div>
                
                <div class="white_circle"></div>
                </div>
            </div>
        </div>
        
        
        <div class="col-md-6">
            <div class="red_box">
                <div class="row">
                <div class="col-md-6 col-xs-6">
                    <img class="img-responsive" src="img/post.jpg">
                </div>
                
                <div class="col-md-6 col-xs-6">
                    <h4><strong>Post</strong><br />Wedding</h4>
                </div>
                
                <div class="white_circle"></div>
                </div>
            </div>
        </div>
        
        
        
    </div>
</div>
<!--wedding section-->

<!--photobook section-->
<div class="photo_book">

<h2>Photo Book</h2>

    <div class="container">
        <div class="row">
            <div class="col-md-3">
                <a class="stack_photo" href="">
                    <img class="img-responsive" src="img/pb1.jpg">
                </a>
            </div>
            
            <div class="col-md-3">
                <a class="stack_photo" href="">
                    <img class="img-responsive" src="img/pb2.jpg">
                </a>
            </div>
            
            <div class="col-md-3">
                <a class="stack_photo" href="">
                    <img class="img-responsive" src="img/pb3.jpg">
                </a>
            </div>
            
            <div class="col-md-3">
                <a class="stack_photo" href="">
                    <img class="img-responsive" src="img/pb4.jpg">
                </a>
            </div>
        </div>
    </div>
</div>
<!--photobook section-->

<!--services-->

<div class="services">
    <div class="container">
        <div class="row">
        <h2>Services</h2>
        
        <div class="col-md-2 ser">
        <a href="">
        <i class="fa fa-users"></i>
        <h4>Corporate<br /> Events</h4>
        </a>
        </div>
        
        <div class="col-md-2 ser">
        <a href="#"><i class="fa fa-pagelines"></i>
        <h4>Nature<br />Photography</h4></a>
        </div>
        
        <div class="col-md-2 ser">
        <a href="#"><i class="fa fa-lightbulb-o"></i>
        <h4>Special <br />Occasion</h4></a>
        </div>
        
        <div class="col-md-2 ser">
       <a href="#"> <i class="fa fa-picture-o"></i>
        <h4>Commercial<br /> Photography</h4></a>
        </div>
        
        <div class="col-md-2 ser">
        <a href="#"><i class="fa fa-smile-o"></i>
        <h4>Babies &amp;<br /> Kids</h4></a>
        </div>
        
        <div class="col-md-2 ser">
        <a href="#"><i class="fa fa-camera-retro"></i>
        <h4>Communion<br /> Photography</h4></a>
        </div>
        
        </div>
    </div>
</div>
<!--services-->

<?php include 'footer.php'; ?>
