<!-- Navigation -->

<div class="container">
	<div class="row">
 
		<div class="col-md-12">
		<a href="index.php">	<h1 class="page-header">
			Maestro - Real Estate
		</h1> </a></div>
        
</div>
</div>        
  <div class="menu">
  <div class="container">
   <div class="row">
        
        
	
	<!--		<div class="header_contact">
				<ul>
					<li>
					<i class="fa-1x fa fa-phone radius"></i>
					123456-7890 </li>
					<li><i class="fa-1x fa fa-envelope-o"></i>
					info@maestro.com </li>
				</ul>
			</div> 
			<div class="navbar-header ">
				<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				</button>
			</div>-->
			<!-- Collect the nav links, forms, and other content for toggling -->
			<div class="collapse navbar-collapse menu-align" id="bs-example-navbar-collapse-1 ">
				<ul class="nav navbar-nav  ">
					<li>
					<a href="index.php">Home</a>
					</li>
					<li class="dropdown">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">Services <b class="caret"></b></a>
					<ul class="dropdown-menu">
						<li>
						<a href="#">Service one</a>
						</li>
						<li>
						<a href="#">Service Two</a>
						</li>
					</ul>
					</li>
					<li>
					<a href="contact.php">Contact</a>
					</li>
				</ul>
			</div>
			<!-- /.navbar-collapse -->
		 
   </div>
  
  
  </div>      
</div>