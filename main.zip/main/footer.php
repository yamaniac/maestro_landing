<div class="footer">
<div class="container">
 
  <div class="row">
    <div class="col-md-4 buffer-text">
    
Copyrights 2016 - Maestro.com
    </div>
    
        <div class="col-md-4 flinks buffer-text">
<ul>
<li><a href="index.php">Home</a>  |</li>
<li><a href="index.php">Services</a>  |</li>
<li><a href="contact.php">Contact Us</a> </li>


</ul>    

    </div>
    


<div class="col-md-4 text-right"> Powered By: <a href="#" title="Pacesoft Technologies"> <img src="images/pacesoft.jpg" width="24" height="24" /></a> </div>    
  
  </div>
</div>
</div>

<!-- /.container -->
<!-- core files  needed to run this site smoothly -->
<script src="js/jquery.js" type="text/javascript"></script> 
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script src="js/waypoint.js" type="text/javascript"></script>
<script src="js/scroll.js" type="text/javascript"></script>
<script src="https://maps.googleapis.com/maps/api/js?callback=initMap" async defer>
        </script>
<script>
  function initMap() {
    var mapDiv = document.getElementById('map');
    var map = new google.maps.Map(mapDiv, {
      center: {lat: 44.540, lng: -78.546},
      zoom: 8
    });
  }
</script>   
        
<script>
    $('.carousel').carousel({
        interval: 5000 //changes the speed
    })
    </script>
</body>
</html>