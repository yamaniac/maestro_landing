<?php include 'header.php'; ?>
<?php include 'menu.php'; ?>

<!-- Header Carousel -->
<header>
<div class="header_container">
<div class="container">
 <div class="row">
  <div class="col-md-3 paddingout os-animation" data-os-animation="fadeInUp" data-os-animation-delay="1.2s" >
    <div class="service color1">
    <h3>Real Estate </h3>
    <img  src="images/real-estate-img1.jpg" class="img-responsive"/>
   
    <a href="#" class="btn btn-lg btn-success">
    Proceed to Site
    </a> 
    </div>
  </div>
      <div class="col-md-3 paddingout os-animation" data-os-animation="fadeInDown" data-os-animation-delay="1s"">
    <div class="service color2">
    <h2>Interiors </h2>
    <img  src="images/real-estate-img1.jpg" class="img-responsive"/>
   
    <a href="#" class="btn btn-lg btn-success">
    Proceed to Site
    </a> 
    </div>
  </div>
      <div class="col-md-3 paddingout os-animation" data-os-animation="fadeInUp" data-os-animation-delay="1.2s"">
    <div class="service color1">
    <h2>Events </h2>
    <img  src="images/real-estate-img1.jpg" class="img-responsive"/>
   
    <a href="#" class="btn btn-lg btn-success">
    Proceed to Site
    </a> 
    </div>
  </div>
      <div class="col-md-3 paddingout os-animation" data-os-animation="fadeInDown" data-os-animation-delay="1s"">
    <div class="service color2">
    <h2>Sports </h2>
    <img  src="images/real-estate-img1.jpg" class="img-responsive"/>
   
    <a href="#" class="btn btn-lg btn-success">
    Proceed to Site
    </a> 
    </div>
  </div>
  
 </div>
</div>

</div>

    </header>
    <!-- Page Content -->

<div class="container">
	<!-- Portfolio Section -->


	<!-- /.row -->
</div>


<div  class="top-buffer"></div>
<div class="container maps">
	<div class="row">
		<div class="col-md-12 descp">
			<h2 class=" center-block descp sc_title">
			<strong>Our</strong> Corporate Office</h2>
			<p>
				We are Located at
			</p>
		</div>
	</div>
</div>

<div class="top-buffer">
</div>
<div class="wrapper maps">
<div id="map">
</div>

<div class="contact_placeholder">
<ul>
<li><i class="fa fa-map-marker"></i> 
 2277 Lorem Ave, San Diego, CA 22553 </li>
<li> <i class="fa fa-clock-o"></i> Monday - Saturday
from 8:00 to 20:00 <br /> <br />

Free day - Sunday </li><br /> <br />
<li><i class="fa fa-phone"></i> 
 123-459-7890 </li>
<li><i class="fa fa-envelope"></i> 
info@maestro.com </li>

</ul>
</div>

</div>
<?php include 'footer.php';?>
